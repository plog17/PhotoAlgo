function [ imHDR ] = assembleHDR( Z,g,B,w )
    %Z est 4-D, Lignes x Colonnes x Canaux x photos

    %Cela impl�mente l'�quation 6 de Debevec 1998. Je trouve plus intuitif
    %de boucler sur les �l�ments qui sont somm�s dans l'�quation
    [row, col, channels, frames] = size(Z);
    logRadiance = zeros(row, col, 3);
       
    for currentChannel = 1:channels
        for x = 1:col
            for y = 1:row
                totalLogExposure = 0;
                totalWeight = 0;
                for currentFrame = 1:frames
                    lZ = Z(y, x, currentChannel, currentFrame) + 1;
                    lg = g(lZ);
                    lB = B(currentFrame);
                    lw = w(lZ);
               
                    totalLogExposure = totalLogExposure + lw * lg - lB;
                    totalWeight = totalWeight + lw;
                end
                logRadiance(y, x, currentChannel) = totalLogExposure / totalWeight;
            end
        end
    end
    
    %Notez que cela produit les valeurs log de la radiance, 
    %donc assurez-vous de faire l'exponentielle du r�sultat et de sauvegarder la radiance absolue.
    imHDR = exp(logRadiance);
    
    %enlever pixels invalides
    index = find(isnan(imHDR) | isinf(imHDR));
    imHDR(index) = 0;
end

