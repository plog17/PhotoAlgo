path='../web/images/origin/sphere/';
path3='../web/images/perso3/sphere/';
path4='../web/images/perso4/sphere/';

addpath('tests/program/')
addpath('radiance/')
addpath('composition/')

%% Carte de radiance
im=GenerateHDR(path3,'perso3');
imshow(im);

im4=GenerateHDR(path4,'perso4');
imshow(im4);

im2=GenerateHDR(path,'origin');
imshow(im2);

%% Transormation panoramique
latlon = generateEquiRectImage(im);

%% Composition
%facteur d'illumination
c=5;
final = compose('../web/images/perso3/blender/',c);
imshow(final);
imwrite(final,'final.jpg');

final4 = compose('../web/images/perso4/blender/',c);
imshow(final4);
imwrite(final4,'final.jpg');



