function [ outIm ] = mergeImages(im1, im2, xOffset, yOffset)
xGap = max(1-xOffset, 0);
yGap = max(1-yOffset, 0);

xBegin=xOffset+xGap;
xEnd=xOffset+xGap+size(im2,2)-1;
yBegin=yOffset+yGap;
yEnd=yOffset+yGap+size(im2,1)-1;

newW=max([xGap+size(im1,2), xOffset+size(im2,2), size(im1,2), size(im2,2)]);
newH=max([yGap+size(im1,1), yOffset+size(im2,1), size(im1,1), size(im2,1)]);

outIm=zeros(newH,newW,3);
outIm2=zeros(newH,newW,3);

imMask=zeros(newH,newW);
imMask(1+yGap:yGap+size(im1,1), 1+xGap:xGap+size(im1,2))=1;
im2Mask=im2(:,:,1);
im2Mask=(.5*ones(size(im2Mask)));
im2Mask(isnan(im2Mask)) = 1;

imMask(yBegin:yEnd,xBegin:xEnd)=imMask(yBegin:yEnd,xBegin:xEnd).*im2Mask;

outIm(1+yGap:yGap+size(im1,1), 1+xGap:xGap+size(im1,2),:)=im1;
outIm2(yBegin:yEnd,xBegin:xEnd,:)=im2;

for i=1:3
    outIm(:,:,i)=outIm(:,:,i).*imMask;
    outIm2(:,:,i)=outIm2(:,:,i).*(ones(newH,newW)-imMask);
end

outIm=outIm+outIm2;

end

