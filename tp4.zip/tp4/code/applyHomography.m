function [ output_args ] = applyHomography( input_args )
%APPLYHOMOGRAPHY Summary of this function goes here
%   Detailed explanation goes here


end

