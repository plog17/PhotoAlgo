batchProcessQ3('/Users/plauger/Pictures/Photographie Algorithmique/TP1/images/perso/','DSC_5599');
batchProcessQ3('/Users/plauger/Pictures/Photographie Algorithmique/TP1/images/perso/','DSC_5596');
batchProcessQ3('/Users/plauger/Pictures/Photographie Algorithmique/TP1/images/perso/','DSC_5605');
batchProcessQ3('/Users/plauger/Pictures/Photographie Algorithmique/TP1/images/perso/','DSC_5611');