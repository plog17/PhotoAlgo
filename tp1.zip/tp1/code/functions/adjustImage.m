function adjusted = adjustImage(im)

adjusted = imadjust(im,[],[],1.3);