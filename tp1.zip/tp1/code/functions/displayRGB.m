function[] = displayRGB(r,g,b)
imshow(r);
pause(1.5);
imshow(g);
pause(1.);
imshow(b);
