%http://lcweb2.loc.gov/service/pnp/prok/00700/00778v.jpg
%http://lcweb2.loc.gov/service/pnp/prok/00700/00716v.jpg
%http://lcweb2.loc.gov/service/pnp/prok/01500/01565v.jpg

addpath('functions');

question1();
%question2();


% Align the images
% Functions that might be useful to you for aligning the images include: 
% "circshift", "sum", and "imresize" (for multiscale)

% create a color image (3D array)
% ... use the "cat" command

% show the resulting image
% ... use the "imshow" command
%figure;imshow(aRGB);

% save result image
%imwrite(aRGB,['result-' imname]);